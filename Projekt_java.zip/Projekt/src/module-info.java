/**
 * 
 */
/**
 * 
 */
module ui {
	requires java.desktop;
	requires jfreechart;
}