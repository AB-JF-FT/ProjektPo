package projekt;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Ui extends JFrame implements ActionListener {
    public static JTextField textField1;
    public static JTextField textField2;
    public static JTextField textField3;
    public static JTextField textField4;
    public static JTextField textField5;
    public static JTextField textField6;
    public JCheckBox useInitialValues;
    public JLabel equationLabel1, equationLabel2, equationLabel3;
    private Graph graph;
    private XYSeriesCollection dataset;
    private JFreeChart chart;
    private ChartPanel chartPanel;

    /**
     * Handles action events.
     *
     * @param e The action event.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle action events
    }

    /**
     * ActionListener for the checkbox.
     */
    ActionListener checkBoxListener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (useInitialValues.isSelected()) {
                textField1.setText("2024.0");
                textField2.setText("10.0");
                textField3.setText("10.0");
                textField4.setText("0.01");
                textField5.setText("2000.0");
                textField6.setText("1.0");

                textField1.setEditable(false);
                textField2.setEditable(false);
                textField3.setEditable(false);
                textField4.setEditable(false);
                textField5.setEditable(false);
                textField6.setEditable(false);
            } else {

                textField1.setEditable(true);
                textField2.setEditable(true);
                textField3.setEditable(true);
                textField4.setEditable(true);
                textField5.setEditable(true);
                textField6.setEditable(true);
            }

        }
    };
    

    /**
     * Creates and sets up the JFreeChart for graph display.
     */
    private void setupChart() {
        // Creates a dataset for the graph
        dataset = new XYSeriesCollection();

        // Creates the chart
        chart = ChartFactory.createXYLineChart(
                "Power Graph", // Title
                "Time", // X-axis label
                "Power", // Y-axis label
                dataset // Dataset
        );

        // Creates a chart panel to display the chart
        chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(500, 400));
    }


    // ActionListener for the start button
    ActionListener startButtonListener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
        	
            // Generates graph data from the Graph class
            graph.createGraph();
            
            // Gets the graph data arrays
            double[] power = graph.power;
            double[] powerJ = graph.powerJ;
            double[] powerU = graph.powerU;
            
            // Clears the dataset
            dataset.removeAllSeries();
            
            // Adds new series to the dataset with custom colors
            XYSeries totalPowerSeries = new XYSeries("Moc Fizjologiczna");
            XYSeries joulePowerSeries = new XYSeries("Moc Jałowa");
            XYSeries usefulPowerSeries = new XYSeries("Moc Użytkowa");

            // Sets colors for each series
            Color blue = Color.BLUE;
            Color red = Color.RED;
            Color green = Color.GREEN;

            for (int i = 0; i < Graph.L; i++) {
                totalPowerSeries.add(graph.time[i], power[i]);
                joulePowerSeries.add(graph.time[i], powerJ[i]);
                usefulPowerSeries.add(graph.time[i], powerU[i]);
            }

            // Sets colors for each series
            dataset.addSeries(totalPowerSeries);
            chart.getXYPlot().getRenderer().setSeriesPaint(dataset.getSeriesCount() - 1, blue);
            dataset.addSeries(joulePowerSeries);
            chart.getXYPlot().getRenderer().setSeriesPaint(dataset.getSeriesCount() - 1, red);
            dataset.addSeries(usefulPowerSeries);
            chart.getXYPlot().getRenderer().setSeriesPaint(dataset.getSeriesCount() - 1, green);
            
            equationLabel1.setText("Praca Fizjologiczna = " + Graph.integral);
            equationLabel1.setForeground(blue);           
            equationLabel1.setOpaque(true);
            equationLabel1.setBackground(Color.GRAY);
            equationLabel2.setText("Praca Jałowa = " + Graph.integralJ);
            equationLabel2.setForeground(red);  
            equationLabel2.setOpaque(true);
            equationLabel2.setBackground(Color.GRAY);
            equationLabel3.setText("Praca Użytkowa= " + Graph.integralU);
            equationLabel3.setForeground(green);  
            equationLabel3.setOpaque(true);
            equationLabel3.setBackground(Color.GRAY);
 
        }
    };
    
    
    private void saveDataToFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Data");
        fileChooser.setFileFilter(new FileNameExtensionFilter("Text Files", "txt")); // Sets filter to text files only
        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (FileWriter writer = new FileWriter(fileToSave + ".txt")) { // Adds .txt extension
            	
                // Writes column headers with proper spacing
                writer.write(String.format("%-10s %-10s %-10s %-10s%n", "time", "power", "powerJ", "powerU"));
                
                // Writes data with proper spacing
                for (int i = 0; i < Graph.L; i++) {
                    writer.write(String.format("%.2f      %.2f      %.2f      %.2f%n",
                            graph.time[i], graph.power[i], graph.powerJ[i], graph.powerU[i]));
                }
                JOptionPane.showMessageDialog(this, "Data saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Saves the graph as an image.
     */
    private void saveGraph() {
        // Creates a buffered image to hold the graph panel content
        BufferedImage image = new BufferedImage(chartPanel.getWidth(), chartPanel.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics2D = image.createGraphics();
        chartPanel.paint(graphics2D);
        graphics2D.dispose();

        // Prompts the user to choose a file location to save the image
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Graph");
        fileChooser.setFileFilter(new FileNameExtensionFilter("JPEG files", "jpg")); // Set filter to JPG files only
        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try {
                // Appends ".jpg" extension if not provided
                if (!fileToSave.getAbsolutePath().toLowerCase().endsWith(".jpg")) {
                    fileToSave = new File(fileToSave.getAbsolutePath() + ".jpg");
                }
                // Saves the buffered image as a JPG file
                javax.imageio.ImageIO.write(image, "jpg", fileToSave);
                JOptionPane.showMessageDialog(this, "Graph saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving graph: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
     * Constructs the UI.
     */
    public Ui() {
        // Sets up the main frame
        setTitle("Graph UI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLayout(new BorderLayout());

        // Creates a menu bar
        JMenuBar menuBar = new JMenuBar();

        // Creates a "File" menu
        JMenu fileMenu = new JMenu("File");

        // Create "Start" menu item and add it to the "File" menu
        JMenuItem startMenuItem = new JMenuItem("Start");
        startMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startButtonListener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));
            }
        });
        fileMenu.add(startMenuItem);

        // Creates "Save" menu item and add it to the "File" menu
        JMenuItem saveMenuItem = new JMenuItem("Save");
        saveMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveGraph();
            }
        });
        fileMenu.add(saveMenuItem);
        
        JMenuItem saveDataMenuItem = new JMenuItem("Save Data");
        saveDataMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveDataToFile();
            }
        });
        fileMenu.add(saveDataMenuItem);
    
        // Adds the "File" menu to the menu bar
        menuBar.add(fileMenu);

        // Sets the menu bar to this frame
        setJMenuBar(menuBar);

        // Sets up the chart
        setupChart();

        // Creates text boxes for values
        textField1 = new JTextField();
        textField2 = new JTextField();
        textField3 = new JTextField();
        textField4 = new JTextField();
        textField5 = new JTextField();
        textField6 = new JTextField();

        // Makes text boxes wider
        int textFieldWidth = 20;
        textField1.setColumns(textFieldWidth);
        textField2.setColumns(textFieldWidth);
        textField3.setColumns(textFieldWidth);
        textField4.setColumns(textFieldWidth);
        textField5.setColumns(textFieldWidth);
        textField6.setColumns(textFieldWidth);

        // Creates a panel for text boxes
        JPanel textBoxPanel = new JPanel(new GridLayout(6, 3, 5, 5));
        textBoxPanel.setPreferredSize(new Dimension(400, 100));

        // Creates labels for text boxes and add them to the panel
        JLabel label1 = new JLabel("V:", SwingConstants.RIGHT);
        textBoxPanel.add(label1);
        textBoxPanel.add(textField1);
        textBoxPanel.add(new JLabel()); // Empty label for spacing

        JLabel label2 = new JLabel("a_0:", SwingConstants.RIGHT);
        textBoxPanel.add(label2);
        textBoxPanel.add(textField2);
        textBoxPanel.add(new JLabel());

        JLabel label3 = new JLabel("c_g:", SwingConstants.RIGHT);
        textBoxPanel.add(label3);
        textBoxPanel.add(textField3);
        textBoxPanel.add(new JLabel());

        JLabel label4 = new JLabel("A:", SwingConstants.RIGHT);
        textBoxPanel.add(label4);
        textBoxPanel.add(textField4);
        textBoxPanel.add(new JLabel());

        JLabel label5 = new JLabel("w:", SwingConstants.RIGHT);
        textBoxPanel.add(label5);
        textBoxPanel.add(textField5);
        textBoxPanel.add(new JLabel());

        JLabel label6 = new JLabel("n:", SwingConstants.RIGHT);
        textBoxPanel.add(label6);
        textBoxPanel.add(textField6);
        useInitialValues = new JCheckBox("Use Initial Values", true);
        textBoxPanel.add(useInitialValues); // Add checkbox for text Fields

        // Adds action listeners to checkboxes
        useInitialValues.addActionListener(checkBoxListener);

        // Sets default values for checkboxes
        checkBoxListener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));

        // Creates a panel for equations and their values
        JPanel equationPanel = new JPanel();
        equationPanel.setLayout(new GridLayout(3, 2, 5, 5));
        equationPanel.setBorder(BorderFactory.createTitledBorder("Obliczone Prace"));

        // Creates labels for equations and add them to the panel
        equationLabel1 = new JLabel("Praca Fizjologiczna=", SwingConstants.CENTER);
        equationLabel2 = new JLabel("Praca Jałowa =", SwingConstants.CENTER);
        equationLabel3 = new JLabel("Praca Użytkowa =", SwingConstants.CENTER);

        equationPanel.add(equationLabel1);
        equationPanel.add(equationLabel2);
        equationPanel.add(equationLabel3);

        // Creates start and save buttons
        JButton startButton = new JButton("Start");

        startButton.addActionListener(startButtonListener);
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveGraph();
            }
        });

        // Creates a panel for the buttons with right alignment
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(startButton);
        buttonPanel.add(saveButton);

        // Creates a panel for bottom components using BorderLayout
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(equationPanel, BorderLayout.CENTER);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Adds panels to the frame
        add(chartPanel, BorderLayout.CENTER);
        add(textBoxPanel, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.PAGE_END);

        // Displays the frame
        setLocationRelativeTo(null);
        setVisible(true);

        // Creates an instance of the Graph class
        graph = new Graph();
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ui());
    }
}
